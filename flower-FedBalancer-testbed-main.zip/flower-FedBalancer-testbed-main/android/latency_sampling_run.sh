#!/bin/bash

python latency_sampling_server.py --client_id=1 &
python latency_sampling_server.py --client_id=2 &
python latency_sampling_server.py --client_id=3 &
python latency_sampling_server.py --client_id=4 &
python latency_sampling_server.py --client_id=5 &
python latency_sampling_server.py --client_id=6 &
python latency_sampling_server.py --client_id=7 &
python latency_sampling_server.py --client_id=8 &
python latency_sampling_server.py --client_id=9 &
python latency_sampling_server.py --client_id=10 &
python latency_sampling_server.py --client_id=11 &
python latency_sampling_server.py --client_id=12 &
python latency_sampling_server.py --client_id=13 &
python latency_sampling_server.py --client_id=14 &
python latency_sampling_server.py --client_id=15 &
python latency_sampling_server.py --client_id=16 &
python latency_sampling_server.py --client_id=17 &
python latency_sampling_server.py --client_id=18 &
python latency_sampling_server.py --client_id=19 &
python latency_sampling_server.py --client_id=20 &
python latency_sampling_server.py --client_id=21 &
