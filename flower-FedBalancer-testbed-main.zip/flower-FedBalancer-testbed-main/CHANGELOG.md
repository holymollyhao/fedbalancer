# Changelog

Flower changes are tracked as part of the documentation: [Flower Changelog](https://flower.dev/docs/changelog.html).

The changelog source can be edited here: `doc/source/changelog.rst`
