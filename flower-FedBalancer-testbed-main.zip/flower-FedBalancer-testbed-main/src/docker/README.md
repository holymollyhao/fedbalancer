# Docker

We provide two docker images. They can be built using the build.sh script in the ./src/docker directory.
The default image will contain the installed flower library with all dependencies to enable easily
trying out flower. The second image is used in tests as well as local runs of baselines using the
FlowerOps package.
