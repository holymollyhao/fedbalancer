warning = """
DEPRECATION WARNING: Example moved to `examples/quickstart_tensorflow`.

All examples will be migrated to the `examples` directory. `flwr_example` will
be removed in a future release.
"""
print(warning)
