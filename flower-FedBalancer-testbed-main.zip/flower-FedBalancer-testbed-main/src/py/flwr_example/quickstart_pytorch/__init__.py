warning = """
DEPRECATION WARNING: Example moved to `examples/quickstart_pytorch`.

All examples will be migrated to the `examples` directory. `flwr_example` will
be removed in a future release.
"""
print(warning)
