Quickstart (Hugging Face [code example])
========================================

Let's build a federated learning system using Hugging Face Transformers and Flower!

Please refer to the `full code example <https://github.com/adap/flower/tree/main/examples/quickstart_huggingface>`_.
