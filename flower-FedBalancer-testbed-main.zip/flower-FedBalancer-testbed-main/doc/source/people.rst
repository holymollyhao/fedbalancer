People
======

.. list-table:: 

    * - .. figure:: _static/profile-daniel.png

           Daniel J. Beutel

      - .. figure:: _static/profile-taner.png

           Taner Topal

    * - .. figure:: _static/profile-nic.png

           Nicholas D. Lane

      - .. figure:: _static/profile-akhil.png

           Akhil Mathur

    * - .. figure:: _static/profile-titouan.png

           Titouan Parcollet

      - .. figure:: _static/profile-xinchi.png

           Xinchi Qiu
