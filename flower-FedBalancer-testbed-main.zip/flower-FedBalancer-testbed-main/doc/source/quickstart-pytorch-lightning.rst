Quickstart (PyTorch Lightning [code example])
=============================================

Let's build a federated learning system using PyTorch Lightning and Flower!

Please refer to the `full code example <https://github.com/adap/flower/tree/main/examples/quickstart_pytorch_lightning>`_.
